package com.egyptiandad.prayer

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

object Notifier {
    const val CHANNEL = "prayer_reminders"

    fun ensureChannel(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) != null) return
        val channel = NotificationChannel(
            CHANNEL,
            context.getString(R.string.channel_name),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = context.getString(R.string.channel_description)
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 400, 200, 400)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        nm.createNotificationChannel(channel)
    }

    fun hasPermission(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun show(context: Context, key: String, isRepeat: Boolean) {
        if (!hasPermission(context)) return
        ensureChannel(context)

        val prayer = Prayer.valueOf(key.substringAfter(':'))
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

        val open = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), flags)
        val prayedIntent = Intent(context, PrayedReceiver::class.java)
            .setAction(PrayedReceiver.ACTION)
            .putExtra(Scheduler.EXTRA_KEY, key)
        val prayed = PendingIntent.getBroadcast(context, key.hashCode(), prayedIntent, flags)

        val title = if (isRepeat) "لسه ما صلّيتش ${prayer.arabic}؟" else "حان وقت ${prayer.arabic}"
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_prayer)
            .setContentTitle(title)
            .setContentText("قوم صلّي، وبعدين اضغط \"صلّيت\".")
            .setContentIntent(open)
            .setAutoCancel(false)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(0, "صلّيت", prayed)
            .build()

        NotificationManagerCompat.from(context).notify(key.hashCode(), notification)
    }

    fun cancel(context: Context, key: String) {
        NotificationManagerCompat.from(context).cancel(key.hashCode())
    }
}
