package com.egyptiandad.prayer

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.tan

enum class Prayer(val arabic: String) {
    FAJR("الفجر"),
    DHUHR("الظهر"),
    ASR("العصر"),
    MAGHRIB("المغرب"),
    ISHA("العشاء")
}

data class City(val id: String, val arabic: String, val lat: Double, val lon: Double)

object Cities {
    val all = listOf(
        City("cairo", "القاهرة / الجيزة", 30.0444, 31.2357),
        City("alex", "الإسكندرية", 31.2001, 29.9187),
        City("mansoura", "المنصورة", 31.0409, 31.3785),
        City("portsaid", "بورسعيد", 31.2653, 32.3019),
        City("luxor", "الأقصر", 25.6872, 32.6396),
        City("aswan", "أسوان", 24.0889, 32.8998)
    )

    fun byId(id: String): City = all.firstOrNull { it.id == id } ?: all[0]
}

/** All times are epoch milliseconds. */
data class DayTimes(
    val date: LocalDate,
    val fajr: Long,
    val sunrise: Long,
    val dhuhr: Long,
    val asr: Long,
    val maghrib: Long,
    val isha: Long
) {
    fun of(p: Prayer): Long = when (p) {
        Prayer.FAJR -> fajr
        Prayer.DHUHR -> dhuhr
        Prayer.ASR -> asr
        Prayer.MAGHRIB -> maghrib
        Prayer.ISHA -> isha
    }
}

/** One prayer window: it starts at [start] and the prayer can be performed until [end]. */
data class PrayerEvent(val prayer: Prayer, val date: LocalDate, val start: Long, val end: Long) {
    val key: String get() = "$date:${prayer.name}"
}

object PrayerTimes {
    val zone: ZoneId = ZoneId.of("Africa/Cairo")

    private const val FAJR_ANGLE = 19.5   // Egyptian General Authority of Survey
    private const val ISHA_ANGLE = 17.5
    private const val SUNRISE_ANGLE = 0.833
    private const val PAD_MS = 3 * 60_000L // small safety margin after zenith, asr and sunset

    private fun Double.rad(): Double = Math.toRadians(this)

    fun today(nowMs: Long): LocalDate = Instant.ofEpochMilli(nowMs).atZone(zone).toLocalDate()

    fun compute(date: LocalDate, city: City): DayTimes {
        val base = date.toEpochDay() * 86_400_000L // UTC midnight of the civil date
        val jd = (base + 12 * 3_600_000.0) / 86_400_000.0 + 2440587.5
        val d = jd - 2451545.0

        val g = (357.529 + 0.98560028 * d) % 360.0
        val q = (280.459 + 0.98564736 * d) % 360.0
        val l = (q + 1.915 * sin(g.rad()) + 0.020 * sin(2 * g.rad())) % 360.0
        val e = 23.439 - 0.00000036 * d

        var ra = Math.toDegrees(atan2(cos(e.rad()) * sin(l.rad()), cos(l.rad()))) / 15.0
        ra = ((ra % 24.0) + 24.0) % 24.0
        val dec = Math.toDegrees(asin(sin(e.rad()) * sin(l.rad())))

        var eq = q / 15.0 - ra
        eq = (((eq + 12.0) % 24.0) + 24.0) % 24.0 - 12.0

        val noon = 12.0 - eq - city.lon / 15.0 // solar noon, hours UTC

        fun hourAngle(altitudeDeg: Double): Double {
            val x = (sin(altitudeDeg.rad()) - sin(dec.rad()) * sin(city.lat.rad())) /
                (cos(dec.rad()) * cos(city.lat.rad()))
            return Math.toDegrees(acos(x.coerceIn(-1.0, 1.0))) / 15.0
        }

        val asrAltitude = Math.toDegrees(atan(1.0 / (1.0 + tan(abs(city.lat - dec).rad()))))
        fun at(hours: Double): Long = base + (hours * 3_600_000.0).toLong()

        return DayTimes(
            date = date,
            fajr = at(noon - hourAngle(-FAJR_ANGLE)),
            sunrise = at(noon - hourAngle(-SUNRISE_ANGLE)),
            dhuhr = at(noon) + PAD_MS,
            asr = at(noon + hourAngle(asrAltitude)) + PAD_MS,
            maghrib = at(noon + hourAngle(-SUNRISE_ANGLE)) + PAD_MS,
            isha = at(noon + hourAngle(-ISHA_ANGLE))
        )
    }

    /** Prayer windows from yesterday to the day after tomorrow, sorted by start time. */
    fun events(city: City, today: LocalDate): List<PrayerEvent> {
        val days = (-1..2).map { compute(today.plusDays(it.toLong()), city) }
        val out = ArrayList<PrayerEvent>()
        for ((i, day) in days.withIndex()) {
            for (p in Prayer.values()) {
                val start = day.of(p)
                val end = when (p) {
                    Prayer.FAJR -> day.sunrise
                    Prayer.DHUHR -> day.asr
                    Prayer.ASR -> day.maghrib
                    Prayer.MAGHRIB -> day.isha
                    Prayer.ISHA -> days.getOrNull(i + 1)?.fajr ?: (start + 3_600_000L)
                }
                out.add(PrayerEvent(p, day.date, start, end))
            }
        }
        return out
    }
}
